<p><img src="https://icodrops.com/wp-content/uploads/2018/05/Mina_logo-150x150.png" alt="Mina logo" title="mina" align="left" height="60" /></p>

# Mina :link: Network Services

Watchdog for Mina testnet
