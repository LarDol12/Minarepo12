"""Entrypoint init"""
from .main import handle_incoming_commit_push_json,config,verify_signature
