#!/bin/bash
set -x #echo on
set -eu

# Kept for backward compatability

./scripts/macos-setup-brew.sh
