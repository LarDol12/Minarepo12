import sys
stdin = sys.stdin.read()
print(stdin.replace('"constraint"', '"constraint_"'))