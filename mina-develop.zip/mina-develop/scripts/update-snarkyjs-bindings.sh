./src/lib/snarkyjs/src/bindings/scripts/update-snarkyjs-bindings.sh
