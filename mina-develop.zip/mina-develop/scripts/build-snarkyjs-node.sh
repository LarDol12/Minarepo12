./src/lib/snarkyjs/src/bindings/scripts/build-snarkyjs-node.sh
