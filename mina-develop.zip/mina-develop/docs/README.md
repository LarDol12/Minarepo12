## Docs

This folder contains some of the docs for codaprotocol.

The docs that are available to view on [the website](https://docs.minaprotocol.com/) can be edited/viewed [here](https://github.com/MinaProtocol/docs)
