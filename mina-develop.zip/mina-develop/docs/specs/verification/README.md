# Verification

## 1 Chain

### 1.1 `isValidChain`

```rust
fn isValidChain(C1) -> bool
{
}
```
