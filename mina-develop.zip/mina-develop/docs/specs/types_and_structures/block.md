# Block structure

| Field    | Type                 | Description |
| - | -    | - |
| `protocol_state`                | ``  | |
| `protocol_state_proof`          | ``  | |
| `staged_ledger_diff`            | ``  | |
| `delta_transition_chain_proof`  | ``  | |
| `current_protocol_version`      | ``  | |
| `proposed_protocol_version_opt` | ``  | |
