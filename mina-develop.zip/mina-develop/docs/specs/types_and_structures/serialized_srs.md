# Serialized SRS

This describes the SRS binary file format

| Field | Type              | Description |
| - | - | - |
| `g`   | `Vector<GAffine>` | For comitting polynomials |
| `h `  | `GAffine`         | Blinding factor |
