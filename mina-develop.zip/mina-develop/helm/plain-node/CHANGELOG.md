
1.0.0:
------
- initial

1.0.2:
------
- All references to the crypto currency now say Mina
