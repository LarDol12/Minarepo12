## Introduction

This chart bootstraps a Mina protocol Testnet plain node, ie a node with no stake, no wallet, no account key, it simply connects to the mina network and vibes