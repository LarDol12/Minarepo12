0.4.5:
------
- enable Artifacthub repository hosting *changes* annotations
- add CHANGELOG.md for chart version => changelog tracking

0.4.6:
------
- add capability to enable/disable daemon genesis proof generation

0.6.0:
------
- add seed-node static external IP chart value
- enable multiple seed-node deployment configurations
- add peers list URL chart value

1.0.0:
------
- coda -> mina

1.0.1:
------
- enable daemon blockchain archival capability

1.0.2:
------
- adds support for uploading blocks to gcloud

1.0.3:
------
- Log precomputed blocks by default
- Add maxConnections value of 200

1.0.7:
------
- All references to the crypto currency now say Mina
