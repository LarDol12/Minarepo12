0.4.5:
------
- enable Artifacthub repository hosting *changes* annotations
- add CHANGELOG.md for chart version => changelog tracking

