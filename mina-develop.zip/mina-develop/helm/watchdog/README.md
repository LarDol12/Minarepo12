## Introduction

This chart bootstraps a Mina protocol Testnet watchdog.

## Add Mina Helm chart repository:

 ```console
 helm repo add mina https://coda-charts.storage.googleapis.com
 helm repo update
 ```
