0.4.6:
------
- enable Artifacthub repository hosting *changes* annotations
- add CHANGELOG.md for chart version => changelog tracking

0.4.7:
------
- add capability to enable/disable daemon genesis proof generation

0.4.8:
------
- fix daemon side-car hostPort reference
- add peers list URL chart value

1.0.0:
------
- coda -> mina

1.0.1:
------
- enable toggle of local daemon and associated postgresDB deployments

1.0.2:
------
- expose archive metrics for collection by (Prometheus) monitoring systems

1.0.6:
------
- All references to the crypto currency now say Mina
