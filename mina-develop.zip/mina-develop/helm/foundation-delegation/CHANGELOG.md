1.0.0:
------
- initial chart version for load balancer and backend deployment
