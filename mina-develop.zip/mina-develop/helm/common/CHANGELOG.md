0.1.2:
------
- - Allow scheduling on GCP spot VMs

0.0.8:
------
- enable Artifacthub repository hosting *changes* annotations
- add CHANGELOG.md for chart version => changelog tracking

