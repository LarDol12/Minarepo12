# Block timing script

## Installation

```sh
yarn install
```

## Build

- Build: `yarn build`
- Clean: `yarn clean`
- Build & watch: `yarn start`

## Run

```sh
node src/Main.bs.js
```
