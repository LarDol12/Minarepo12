0.1.10:
------
- enable Artifacthub repository hosting *changes* annotations
- add CHANGELOG.md for chart version => changelog tracking
0.1.11:
------
- removed duplicate instance of archive node that was used to support testworld network restart
0.1.12:
------
- moved SPREADSHEET_ID env var to helm chart from Dockerfile
