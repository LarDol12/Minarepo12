#!/bin/bash

dropdb archive_backup