#!/bin/bash

pgrep -f --newest "python3 /mina_daemon_puppeteer.py"
